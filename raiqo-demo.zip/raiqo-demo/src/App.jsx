// src/App.jsx
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './contexts/AuthContext'
import Layout from './components/layout/Layout'
import SignIn from './components/auth/SignIn'
import ChangePassword from './components/auth/ChangePassword'
import Dashboard from './components/dashboard/Dashboard'
import Registrations from './components/registrations/Registrations'
import RAUpdates from './components/updates/RAUpdates'
import Variations from './components/variations/Variations'
import BatchRelease from './components/batch/BatchRelease'
import Vendors from './components/vendors/Vendors'
import Notifications from './components/notifications/Notifications'
import Admin from './components/admin/Admin'
import Reports from './components/reports/Reports'

function PrivateRoute({ children }) {
  const { user, profile, loading } = useAuth()
  if (loading) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100vh'}}><div className="spinner"/></div>
  if (!user || !profile) return <Navigate to="/signin" replace />
  // Force password change on first login
  if (!profile.passwordChanged) return <Navigate to="/change-password" replace />
  return children
}

function PublicRoute({ children }) {
  const { user, profile, loading } = useAuth()
  if (loading) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100vh'}}><div className="spinner"/></div>
  if (user && profile?.passwordChanged) return <Navigate to="/" replace />
  return children
}

export default function App() {
  return (
    <Routes>
      <Route path="/signin" element={<PublicRoute><SignIn /></PublicRoute>} />
      <Route path="/change-password" element={<ChangePassword />} />
      <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
        <Route index element={<Dashboard />} />
        <Route path="registrations" element={<Registrations />} />
        <Route path="updates" element={<RAUpdates />} />
        <Route path="variations" element={<Variations />} />
        <Route path="batch" element={<BatchRelease />} />
        <Route path="vendors" element={<Vendors />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="reports" element={<Reports />} />
        <Route path="admin" element={<Admin />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
