// src/components/updates/RAUpdates.jsx
import { useState } from 'react'
import { SAMPLE_RA_UPDATES, PRODUCTS, MARKETS } from '../../data/sampleData'
import { sendEmailNotification, sendWhatsAppNotification } from '../../services/notifications'
import { Plus, Bell, Mail, MessageCircle } from 'lucide-react'

const PRIORITY_CLASS = { critical:'pill-critical', high:'pill-high', medium:'pill-medium', low:'pill-low' }
const STATUS_CLASS = { implemented:'pill-active', approved:'pill-active', qa_approved:'pill-active', submitted:'pill-pending', qa_pending:'pill-review', under_review:'pill-review' }

export default function RAUpdates() {
  const [updates, setUpdates] = useState(SAMPLE_RA_UPDATES)
  const [showForm, setShowForm] = useState(false)
  const [notifResult, setNotifResult] = useState('')
  const [sending, setSending] = useState(false)
  const [form, setForm] = useState({ productId:'', market:'', updateType:'Variation', subcategory:'API Supplier Change', ccfNumber:'', oldValue:'', newValue:'', description:'', implementationDeadline:'', priority:'high', components:[] })

  const COMPONENT_OPTIONS = ['API','FPS','Artwork','Process','Packaging','Storage','Commercial','Registration','Site']

  function toggleComp(c) {
    setForm(f => ({ ...f, components: f.components.includes(c) ? f.components.filter(x=>x!==c) : [...f.components, c] }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    const newUpdate = { ...form, id:`UPD-${String(updates.length+1).padStart(3,'0')}`, status:'qa_pending', createdBy:'Current User', createdAt: new Date().toISOString().slice(0,10) }
    setUpdates(u => [newUpdate, ...u])
    setShowForm(false)
    // Send notification demo
    setNotifResult('Update submitted. Notifications being sent to QA team…')
    setTimeout(() => setNotifResult(''), 4000)
  }

  async function demoSendEmail() {
    setSending(true)
    const res = await sendEmailNotification({
      to_email: import.meta.env.VITE_DEMO_EMAIL || 'demo@example.com',
      to_name: 'QA Manager',
      subject: 'RAIQO Alert: New Regulatory Update — Action Required',
      message: 'A new critical regulatory update (API Supplier Change) has been submitted for Veloxin 500mg · UAE. QA assessment required within 48 hours.',
      event_type: 'RA Update Submitted',
      product_name: 'Veloxin 500mg',
      market: 'UAE',
    })
    setSending(false)
    setNotifResult(res.success ? '✓ Email sent successfully to QA Manager!' : `Email failed: ${res.error?.text || 'Check EmailJS config'}`)
    setTimeout(() => setNotifResult(''), 5000)
  }

  async function demoSendWA() {
    const phone = import.meta.env.VITE_DEMO_WA_PHONE
    const apiKey = import.meta.env.VITE_DEMO_WA_APIKEY
    if (!phone || !apiKey) {
      setNotifResult('⚠ WhatsApp not configured. Add VITE_DEMO_WA_PHONE and VITE_DEMO_WA_APIKEY to .env')
      setTimeout(() => setNotifResult(''), 5000)
      return
    }
    setSending(true)
    const res = await sendWhatsAppNotification({ phone, apiKey, message: '🚨 RAIQO Alert\nNew Critical RA Update\nVeloxin 500mg · UAE · API Supplier Change\nCCF: CCF/2025/0441\nQA assessment required within 48h.' })
    setSending(false)
    setNotifResult(res.success ? '✓ WhatsApp alert sent!' : `WhatsApp failed: ${res.error}`)
    setTimeout(() => setNotifResult(''), 5000)
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Regulatory updates</div>
          <div className="page-sub">Replacing email broadcasts with structured data</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn" onClick={demoSendEmail} disabled={sending}><Mail size={13}/> Demo email</button>
          <button className="btn" onClick={demoSendWA} disabled={sending}><MessageCircle size={13}/> Demo WhatsApp</button>
          <button className="btn btn-primary" onClick={() => setShowForm(true)}><Plus size={13}/> New update</button>
        </div>
      </div>

      {notifResult && (
        <div style={{background: notifResult.startsWith('✓') ? '#D1FAE5' : notifResult.startsWith('⚠') ? '#FEF3C7' : '#EDE9FE', border:'0.5px solid', borderColor: notifResult.startsWith('✓') ? '#6EE7B7' : notifResult.startsWith('⚠') ? '#FCD34D' : '#C4B5FD', borderRadius:8, padding:'10px 14px', fontSize:12, fontWeight:500, color: notifResult.startsWith('✓') ? '#065F46' : notifResult.startsWith('⚠') ? '#92400E' : '#5B21B6', marginBottom:'1rem'}}>
          {notifResult}
        </div>
      )}

      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">New regulatory update</div>
            <form onSubmit={handleSubmit} style={{display:'flex',flexDirection:'column',gap:12}}>
              <div className="grid2">
                <div><label className="label">Product</label>
                  <select className="select" value={form.productId} onChange={e=>setForm(f=>({...f,productId:e.target.value}))} required>
                    <option value="">Select product…</option>
                    {PRODUCTS.slice(0,20).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
                <div><label className="label">Market</label>
                  <select className="select" value={form.market} onChange={e=>setForm(f=>({...f,market:e.target.value}))} required>
                    <option value="">Select market…</option>
                    {MARKETS.map(m => <option key={m.id} value={m.id}>{m.name} ({m.authority})</option>)}
                  </select>
                </div>
              </div>
              <div className="grid2">
                <div><label className="label">Update type</label>
                  <select className="select" value={form.updateType} onChange={e=>setForm(f=>({...f,updateType:e.target.value}))}>
                    {['Variation','Renewal','New Registration','Price Revision','License'].map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div><label className="label">Subcategory</label>
                  <select className="select" value={form.subcategory} onChange={e=>setForm(f=>({...f,subcategory:e.target.value}))}>
                    {['API Supplier Change','Shelf Life Change','FPS Update','Artwork Change','Price Revision','Registration Renewal','GMP Certificate','New Registration'].map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <div><label className="label">CCF number</label><input className="input" value={form.ccfNumber} onChange={e=>setForm(f=>({...f,ccfNumber:e.target.value}))} placeholder="e.g. CCF/2026/0200/A/1" required/></div>
              <div className="grid2">
                <div><label className="label">Old value</label><input className="input" value={form.oldValue} onChange={e=>setForm(f=>({...f,oldValue:e.target.value}))} placeholder="Previous value"/></div>
                <div><label className="label">New value</label><input className="input" value={form.newValue} onChange={e=>setForm(f=>({...f,newValue:e.target.value}))} placeholder="New value"/></div>
              </div>
              <div><label className="label">Description</label>
                <textarea className="input" rows={2} style={{height:'auto',padding:'8px 10px'}} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} placeholder="Describe the change…" required/>
              </div>
              <div className="grid2">
                <div><label className="label">Implementation deadline</label><input type="date" className="input" value={form.implementationDeadline} onChange={e=>setForm(f=>({...f,implementationDeadline:e.target.value}))} required/></div>
                <div><label className="label">Priority</label>
                  <select className="select" value={form.priority} onChange={e=>setForm(f=>({...f,priority:e.target.value}))}>
                    {['critical','high','medium','low'].map(p => <option key={p} value={p}>{p.charAt(0).toUpperCase()+p.slice(1)}</option>)}
                  </select>
                </div>
              </div>
              <div><label className="label">Affected components</label>
                <div style={{display:'flex',flexWrap:'wrap',gap:6,marginTop:4}}>
                  {COMPONENT_OPTIONS.map(c => (
                    <button type="button" key={c} onClick={() => toggleComp(c)}
                      style={{padding:'4px 12px',borderRadius:20,border:'0.5px solid',fontSize:11,fontWeight:500,cursor:'pointer',
                        background: form.components.includes(c) ? 'rgba(123,97,255,0.1)' : 'transparent',
                        borderColor: form.components.includes(c) ? '#7B61FF' : '#d1d5db',
                        color: form.components.includes(c) ? '#7B61FF' : '#6b7280',
                      }}>{c}</button>
                  ))}
                </div>
              </div>
              <div style={{display:'flex',gap:8,justifyContent:'flex-end',marginTop:4}}>
                <button type="button" className="btn" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Submit & notify QA</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="card" style={{padding:0,overflow:'hidden'}}>
        <div className="table-wrap">
          <table>
            <thead><tr>
              <th>CCF No.</th><th>Product</th><th>Market</th><th>Type</th>
              <th>Component</th><th>Priority</th><th>Deadline</th><th>Status</th><th></th>
            </tr></thead>
            <tbody>
              {updates.map(u => {
                const prod = PRODUCTS.find(p => p.id === u.productId)
                return (
                  <tr key={u.id}>
                    <td><span className="mono">{u.ccfNumber}</span></td>
                    <td style={{fontWeight:500}}>{prod?.name || u.productId}</td>
                    <td>{u.market}</td>
                    <td style={{color:'#6b7280',fontSize:11}}>{u.subcategory}</td>
                    <td>{u.components?.join(', ') || '—'}</td>
                    <td><span className={`pill ${PRIORITY_CLASS[u.priority]}`}>{u.priority}</span></td>
                    <td style={{color: new Date(u.implementationDeadline) < new Date() ? '#E53E3E' : undefined, fontWeight: new Date(u.implementationDeadline) < new Date() ? 600 : undefined}}>{u.implementationDeadline}</td>
                    <td><span className={`pill ${STATUS_CLASS[u.status]||'pill-pending'}`}>{u.status.replace(/_/g,' ')}</span></td>
                    <td><button className="btn btn-sm">View</button></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
