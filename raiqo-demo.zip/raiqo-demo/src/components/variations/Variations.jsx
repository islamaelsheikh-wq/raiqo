// src/components/variations/Variations.jsx
import { SAMPLE_RA_UPDATES, PRODUCTS } from '../../data/sampleData'
export default function Variations() {
  const variations = SAMPLE_RA_UPDATES.filter(u => u.updateType === 'Variation')
  const STATUS_CLASS = { implemented:'pill-active', approved:'pill-active', qa_approved:'pill-active', submitted:'pill-pending', qa_pending:'pill-review', under_review:'pill-review' }
  return (
    <div>
      <div className="page-header"><div><div className="page-title">Variations</div><div className="page-sub">Post-approval changes and implementation tracking</div></div></div>
      <div className="card" style={{padding:0,overflow:'hidden'}}>
        <div className="table-wrap">
          <table>
            <thead><tr><th>CCF No.</th><th>Product</th><th>Market</th><th>Change type</th><th>Old value</th><th>New value</th><th>Deadline</th><th>Components</th><th>Status</th></tr></thead>
            <tbody>
              {variations.map(u => {
                const prod = PRODUCTS.find(p => p.id === u.productId)
                return (
                  <tr key={u.id}>
                    <td><span className="mono">{u.ccfNumber}</span></td>
                    <td style={{fontWeight:500}}>{prod?.name || u.productId}</td>
                    <td>{u.market}</td>
                    <td style={{fontSize:11,color:'#6b7280'}}>{u.subcategory}</td>
                    <td style={{fontSize:11,maxWidth:120,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{u.oldValue}</td>
                    <td style={{fontSize:11,maxWidth:120,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{u.newValue}</td>
                    <td>{u.implementationDeadline}</td>
                    <td style={{fontSize:11}}>{u.components?.join(', ')}</td>
                    <td><span className={`pill ${STATUS_CLASS[u.status]||'pill-pending'}`}>{u.status.replace(/_/g,' ')}</span></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
