// src/components/registrations/Registrations.jsx
import { useState } from 'react'
import { SAMPLE_REGISTRATIONS, PRODUCTS, MARKETS } from '../../data/sampleData'
import { Plus, Filter } from 'lucide-react'

const STATUS_CLASS = { active:'pill-active', review:'pill-review', expired:'pill-blocked', renewal_due:'pill-review', pending:'pill-pending' }

export default function Registrations() {
  const [search, setSearch] = useState('')
  const [filterMarket, setFilterMarket] = useState('')
  const [filterStatus, setFilterStatus] = useState('')

  const filtered = SAMPLE_REGISTRATIONS.filter(r => {
    const prod = PRODUCTS.find(p => p.id === r.productId)
    const matchSearch = !search || prod?.name.toLowerCase().includes(search.toLowerCase()) || r.regNumber.toLowerCase().includes(search.toLowerCase())
    const matchMarket = !filterMarket || r.market === filterMarket
    const matchStatus = !filterStatus || r.status === filterStatus
    return matchSearch && matchMarket && matchStatus
  })

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Product registrations</div>
          <div className="page-sub">{SAMPLE_REGISTRATIONS.length} registrations across all markets</div>
        </div>
        <button className="btn btn-primary"><Plus size={13}/> Add registration</button>
      </div>

      {/* Filters */}
      <div style={{display:'flex',gap:8,marginBottom:'1rem',flexWrap:'wrap'}}>
        <input className="input" placeholder="Search by product or reg number…" value={search} onChange={e=>setSearch(e.target.value)} style={{width:240}}/>
        <select className="select" value={filterMarket} onChange={e=>setFilterMarket(e.target.value)} style={{width:140}}>
          <option value="">All markets</option>
          {MARKETS.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
        </select>
        <select className="select" value={filterStatus} onChange={e=>setFilterStatus(e.target.value)} style={{width:160}}>
          <option value="">All statuses</option>
          <option value="active">Active</option>
          <option value="renewal_due">Renewal due</option>
          <option value="review">Under review</option>
          <option value="expired">Expired</option>
        </select>
        <div style={{fontSize:12,color:'#9ca3af',display:'flex',alignItems:'center',marginLeft:'auto'}}>{filtered.length} results</div>
      </div>

      <div className="card" style={{padding:0,overflow:'hidden'}}>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Reg. number</th><th>Product</th><th>Market</th><th>Authority</th>
                <th>Status</th><th>Expiry date</th><th>Renewal due</th><th>Version</th><th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => {
                const prod = PRODUCTS.find(p => p.id === r.productId)
                const isUrgent = r.status === 'renewal_due' || r.status === 'expired'
                return (
                  <tr key={r.id} style={{background: isUrgent ? '#fffbeb' : undefined}}>
                    <td><span className="mono">{r.regNumber}</span></td>
                    <td style={{fontWeight:500}}>{prod?.name || r.productId}</td>
                    <td>{r.market}</td>
                    <td style={{color:'#6b7280'}}>{r.authority}</td>
                    <td><span className={`pill ${STATUS_CLASS[r.status]||'pill-pending'}`}>{r.status.replace('_',' ')}</span></td>
                    <td style={{color: isUrgent ? '#E53E3E' : undefined, fontWeight: isUrgent ? 600 : undefined}}>{r.expiryDate}</td>
                    <td style={{color: r.status === 'renewal_due' ? '#D97706' : undefined, fontWeight: r.status === 'renewal_due' ? 600 : undefined}}>{r.renewalDueDate}</td>
                    <td style={{color:'#9ca3af'}}>{r.version}</td>
                    <td><button className="btn btn-sm">View</button></td>
                  </tr>
                )
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={9} style={{textAlign:'center',padding:'2rem',color:'#9ca3af'}}>No registrations match the filter</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid4" style={{marginTop:'1rem'}}>
        {[['Active',SAMPLE_REGISTRATIONS.filter(r=>r.status==='active').length,'#059669'],
          ['Renewal due',SAMPLE_REGISTRATIONS.filter(r=>r.status==='renewal_due').length,'#D97706'],
          ['Under review',SAMPLE_REGISTRATIONS.filter(r=>r.status==='review').length,'#7B61FF'],
          ['Expired',SAMPLE_REGISTRATIONS.filter(r=>r.status==='expired').length,'#E53E3E'],
        ].map(([label,val,color]) => (
          <div key={label} className="card" style={{padding:'12px 14px',borderLeft:`3px solid ${color}`}}>
            <div style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.07em',color:'#9ca3af'}}>{label}</div>
            <div style={{fontSize:22,fontWeight:700,color,marginTop:2}}>{val}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
