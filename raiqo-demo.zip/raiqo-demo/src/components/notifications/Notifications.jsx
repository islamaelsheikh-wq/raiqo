// src/components/notifications/Notifications.jsx
import { useState } from 'react'
import { sendEmailNotification, sendWhatsAppNotification, NOTIFICATION_RULES } from '../../services/notifications'
import { Bell, Mail, MessageCircle, CheckCircle } from 'lucide-react'

const DEMO_NOTIFICATIONS = [
  { id:1, type:'critical', channel:'email+whatsapp', title:'Batch VLX-2026-047 BLOCKED', body:'API vendor not approved for UAE market. QA Manager action required.', time:'2 hours ago', read:false },
  { id:2, type:'high', channel:'email', title:'New RA update requires QA assessment', body:'Veloxin 500mg · API Supplier Change · CCF/2025/0441 · Due within 48h', time:'3 hours ago', read:false },
  { id:3, type:'high', channel:'email', title:'Registration renewal due in 38 days', body:'Medobal 10mg · MOHAP UAE · Action required before 2025-04-04', time:'1 day ago', read:true },
  { id:4, type:'critical', channel:'whatsapp+email', title:'SAP vendor mismatch detected', body:'Synthexia Labs India · Not matching RAIQO AVL · Procurement action required', time:'2 days ago', read:true },
  { id:5, type:'medium', channel:'email', title:'Variation CCF/2025/0502 approved', body:'Claritex Syrup · FPS Update · Jordan · Implementation actions generated', time:'3 days ago', read:true },
]

const TYPE_COLOR = { critical:'#E53E3E', high:'#D97706', medium:'#7B61FF', low:'#059669' }

export default function Notifications() {
  const [notifications, setNotifications] = useState(DEMO_NOTIFICATIONS)
  const [sending, setSending] = useState('')
  const [result, setResult] = useState('')

  function markRead(id) { setNotifications(n => n.map(x => x.id === id ? {...x, read:true} : x)) }

  async function testEmail() {
    setSending('email')
    const res = await sendEmailNotification({
      to_email: import.meta.env.VITE_DEMO_EMAIL || 'demo@example.com',
      to_name: 'Demo User',
      subject: 'RAIQO Test Notification — System Working',
      message: 'This is a test notification from RAIQO Demo. The email notification system is configured and working correctly.',
      event_type: 'System Test',
    })
    setSending('')
    setResult(res.success ? '✓ Test email sent! Check your inbox.' : `Failed: ${res.error?.text || 'Check EmailJS settings in Admin panel'}`)
    setTimeout(() => setResult(''), 6000)
  }

  async function testWhatsApp() {
    const phone = import.meta.env.VITE_DEMO_WA_PHONE
    const apiKey = import.meta.env.VITE_DEMO_WA_APIKEY
    if (!phone || !apiKey) {
      setResult('⚠ Configure VITE_DEMO_WA_PHONE and VITE_DEMO_WA_APIKEY in .env file')
      setTimeout(() => setResult(''), 5000)
      return
    }
    setSending('wa')
    const res = await sendWhatsAppNotification({ phone, apiKey, message: '✅ RAIQO Demo Test\nWhatsApp notifications are working!\nThis message was sent from the RAIQO platform.' })
    setSending('')
    setResult(res.success ? '✓ WhatsApp test sent!' : `Failed: ${res.error}`)
    setTimeout(() => setResult(''), 6000)
  }

  const unread = notifications.filter(n => !n.read).length

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Alerts & notifications {unread > 0 && <span style={{marginLeft:8,fontSize:13,fontWeight:600,padding:'2px 10px',borderRadius:20,background:'#FEE2E2',color:'#991B1B'}}>{unread} unread</span>}</div>
          <div className="page-sub">All system alerts, regulatory deadlines, and compliance notifications</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn" onClick={testEmail} disabled={!!sending}><Mail size={13}/> {sending==='email'?'Sending…':'Test email'}</button>
          <button className="btn" onClick={testWhatsApp} disabled={!!sending}><MessageCircle size={13}/> {sending==='wa'?'Sending…':'Test WhatsApp'}</button>
        </div>
      </div>

      {result && (
        <div style={{background: result.startsWith('✓')?'#D1FAE5':result.startsWith('⚠')?'#FEF3C7':'#FEE2E2', border:'0.5px solid', borderColor: result.startsWith('✓')?'#6EE7B7':result.startsWith('⚠')?'#FCD34D':'#FCA5A5', borderRadius:8, padding:'10px 14px', fontSize:12, fontWeight:500, color: result.startsWith('✓')?'#065F46':result.startsWith('⚠')?'#92400E':'#991B1B', marginBottom:'1rem'}}>
          {result}
        </div>
      )}

      <div className="grid2" style={{marginBottom:'1rem'}}>
        <div className="card" style={{padding:'12px 14px'}}>
          <div style={{fontSize:11,fontWeight:600,textTransform:'uppercase',letterSpacing:'.08em',color:'#9ca3af',marginBottom:8}}>Notification rules</div>
          <div style={{display:'flex',flexDirection:'column',gap:6}}>
            {Object.entries(NOTIFICATION_RULES).map(([key,rule]) => (
              <div key={key} style={{display:'flex',alignItems:'center',gap:8,fontSize:11}}>
                <div style={{width:6,height:6,borderRadius:'50%',background:rule.priority==='critical'?'#E53E3E':rule.priority==='high'?'#D97706':'#7B61FF',flexShrink:0}}/>
                <span style={{flex:1}}>{rule.label}</span>
                <span style={{fontSize:9,color:'#9ca3af'}}>{rule.notifyRoles.length} roles</span>
              </div>
            ))}
          </div>
        </div>
        <div className="card" style={{padding:'12px 14px'}}>
          <div style={{fontSize:11,fontWeight:600,textTransform:'uppercase',letterSpacing:'.08em',color:'#9ca3af',marginBottom:8}}>Channels configured</div>
          {[
            { label:'In-app (real-time)', status: true, icon: Bell, note:'SignalR — Phase 2' },
            { label:'Email (EmailJS + Gmail)', status: !!import.meta.env.VITE_EMAILJS_SERVICE_ID, icon: Mail, note: import.meta.env.VITE_EMAILJS_SERVICE_ID ? 'Active' : 'Add to .env' },
            { label:'WhatsApp (CallMeBot)', status: !!import.meta.env.VITE_DEMO_WA_PHONE, icon: MessageCircle, note: import.meta.env.VITE_DEMO_WA_PHONE ? 'Active' : 'Add to .env' },
          ].map(c => (
            <div key={c.label} style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
              <c.icon size={14} color={c.status?'#059669':'#9ca3af'}/>
              <span style={{flex:1,fontSize:12}}>{c.label}</span>
              <span style={{fontSize:10,fontWeight:500,color:c.status?'#059669':'#9ca3af'}}>{c.note}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="card" style={{padding:0,overflow:'hidden'}}>
        <div style={{padding:'10px 14px',borderBottom:'0.5px solid rgba(0,0,0,0.07)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{fontSize:11,fontWeight:600}}>Recent notifications</div>
          <button onClick={() => setNotifications(n => n.map(x => ({...x, read:true})))} style={{background:'none',border:'none',fontSize:11,color:'#7B61FF',cursor:'pointer'}}>Mark all read</button>
        </div>
        {notifications.map(n => (
          <div key={n.id} onClick={() => markRead(n.id)} style={{display:'flex',gap:12,padding:'12px 14px',borderBottom:'0.5px solid rgba(0,0,0,0.05)',background: n.read ? undefined : '#fafbff',cursor:'pointer'}}>
            <div style={{width:8,height:8,borderRadius:'50%',background:TYPE_COLOR[n.type],flexShrink:0,marginTop:4}}/>
            <div style={{flex:1}}>
              <div style={{fontSize:12,fontWeight: n.read ? 400 : 600}}>{n.title}</div>
              <div style={{fontSize:11,color:'#6b7280',marginTop:2}}>{n.body}</div>
              <div style={{display:'flex',gap:8,marginTop:4}}>
                <span style={{fontSize:10,color:'#9ca3af'}}>{n.time}</span>
                <span style={{fontSize:10,color:'#9ca3af'}}>via {n.channel}</span>
              </div>
            </div>
            {!n.read && <div style={{width:6,height:6,borderRadius:'50%',background:'#7B61FF',flexShrink:0,marginTop:4}}/>}
          </div>
        ))}
      </div>
    </div>
  )
}
