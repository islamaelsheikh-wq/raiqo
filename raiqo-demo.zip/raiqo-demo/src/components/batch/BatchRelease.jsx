// src/components/batch/BatchRelease.jsx
import { useState } from 'react'
import { SAMPLE_BATCHES, SAMPLE_REGISTRATIONS, SAMPLE_VENDORS, PRODUCTS } from '../../data/sampleData'
import { ShieldCheck, ShieldX, AlertTriangle, CheckCircle, XCircle } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'

function runCheck(batch) {
  const product = PRODUCTS.find(p => p.id === batch.productId)
  const reg = SAMPLE_REGISTRATIONS.find(r => r.productId === batch.productId && r.market === batch.market)
  const vendor = SAMPLE_VENDORS.find(v => v.id === batch.vendorId)

  const checks = [
    { name:'Registration active', pass: !!reg && reg.status === 'active', note: reg ? `${reg.regNumber} · Exp ${reg.expiryDate}` : 'No active registration found' },
    { name:'API vendor approved', pass: !!vendor && vendor.qualStatus === 'approved', note: vendor ? `${vendor.name} · ${vendor.qualStatus}` : 'Vendor not found' },
    { name:'Manufacturing site approved', pass: true, note:'Site SITE-001 · GMP cert valid 2029' },
    { name:'No critical open variations', pass: batch.status !== 'blocked', note: batch.status === 'blocked' ? 'Open critical variation — CCF/2025/0441' : 'No blocking variations' },
    { name:'No open change controls', pass: batch.status !== 'blocked', note: batch.status === 'blocked' ? 'CC #CC-2025-0078 open' : 'All change controls closed' },
  ]

  const failed = checks.filter(c => !c.pass)
  const decision = failed.length > 0 ? 'block' : 'allow'
  return { checks, decision, failed }
}

export default function BatchRelease() {
  const { profile } = useAuth()
  const [selected, setSelected] = useState(null)
  const [result, setResult] = useState(null)
  const [overrideMode, setOverrideMode] = useState(false)
  const [overrideText, setOverrideText] = useState('')
  const [released, setReleased] = useState({})

  function runBatchCheck(batch) {
    setSelected(batch)
    setResult(runCheck(batch))
    setOverrideMode(false)
    setOverrideText('')
  }

  function handleRelease() {
    if (!result) return
    setReleased(r => ({ ...r, [selected.id]: true }))
    setResult(null); setSelected(null)
  }

  function handleOverride() {
    if (overrideText.length < 20) return alert('Justification must be at least 20 characters.')
    setReleased(r => ({ ...r, [selected.id]: 'overridden' }))
    setResult(null); setSelected(null); setOverrideMode(false)
  }

  const canOverride = profile?.role === 'qa_manager' || profile?.role === 'app_admin'

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Batch release gate</div>
          <div className="page-sub">Pre-release regulatory compliance verification</div>
        </div>
      </div>

      <div className="grid2">
        {/* Batch list */}
        <div>
          <div style={{fontSize:11,fontWeight:600,textTransform:'uppercase',letterSpacing:'.08em',color:'#9ca3af',marginBottom:8}}>Batches awaiting check</div>
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            {SAMPLE_BATCHES.map(batch => {
              const prod = PRODUCTS.find(p => p.id === batch.productId)
              const isReleased = !!released[batch.id]
              const isSelected = selected?.id === batch.id
              return (
                <div key={batch.id} className="card" style={{padding:'12px 14px', border: isSelected ? '1.5px solid #7B61FF' : '0.5px solid rgba(0,0,0,0.1)', cursor:'pointer', background: isReleased ? '#f0fdf4' : undefined}}
                  onClick={() => !isReleased && runBatchCheck(batch)}>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
                    <div>
                      <div style={{fontSize:13,fontWeight:600}}>{prod?.name}</div>
                      <div style={{fontSize:11,color:'#6b7280',marginTop:2}}><span className="mono">{batch.batchNumber}</span> · {batch.market}</div>
                    </div>
                    {isReleased ? (
                      <span style={{fontSize:10,fontWeight:600,padding:'3px 10px',borderRadius:20,background:'#D1FAE5',color:'#065F46'}}>
                        {released[batch.id] === 'overridden' ? 'Released (override)' : 'Released'}
                      </span>
                    ) : (
                      <span style={{fontSize:10,fontWeight:600,padding:'3px 10px',borderRadius:20,background:batch.status==='blocked'?'#FEE2E2':'#EDE9FE',color:batch.status==='blocked'?'#991B1B':'#5B21B6'}}>
                        {batch.status === 'blocked' ? 'Blocked' : 'Check needed'}
                      </span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Check result */}
        <div>
          <div style={{fontSize:11,fontWeight:600,textTransform:'uppercase',letterSpacing:'.08em',color:'#9ca3af',marginBottom:8}}>Compliance check result</div>
          {!result ? (
            <div className="card" style={{padding:'2rem',textAlign:'center',color:'#9ca3af'}}>
              <ShieldCheck size={32} style={{margin:'0 auto 12px',opacity:.3}}/>
              <div style={{fontSize:13}}>Select a batch to run compliance check</div>
            </div>
          ) : (
            <div className="card" style={{padding:'14px',borderColor: result.decision==='allow'?'#6EE7B7':'#FCA5A5',borderWidth:1.5}}>
              <div style={{fontSize:12,fontWeight:600,marginBottom:10}}>
                {PRODUCTS.find(p=>p.id===selected?.productId)?.name} · {selected?.market}
                <span className="mono" style={{fontSize:11,color:'#9ca3af',marginLeft:6}}>{selected?.batchNumber}</span>
              </div>

              <div style={{display:'flex',flexDirection:'column',gap:6,marginBottom:12}}>
                {result.checks.map(c => (
                  <div key={c.name} style={{display:'flex',alignItems:'flex-start',gap:8,padding:'7px 10px',borderRadius:8,background:c.pass?'#F0FDF4':'#FEF2F2'}}>
                    {c.pass ? <CheckCircle size={16} color="#059669" style={{flexShrink:0}}/> : <XCircle size={16} color="#E53E3E" style={{flexShrink:0}}/>}
                    <div>
                      <div style={{fontSize:12,fontWeight:500,color:c.pass?'#065F46':'#991B1B'}}>{c.name}</div>
                      <div style={{fontSize:10,color:c.pass?'#6b7280':'#EF4444',marginTop:1}}>{c.note}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Decision */}
              <div style={{padding:'10px 14px',borderRadius:8,display:'flex',alignItems:'center',gap:10,background: result.decision==='allow'?'#D1FAE5':'#FEE2E2',marginBottom:12}}>
                {result.decision === 'allow' ? <ShieldCheck size={18} color="#059669"/> : <ShieldX size={18} color="#E53E3E"/>}
                <div style={{fontSize:13,fontWeight:700,color:result.decision==='allow'?'#065F46':'#991B1B'}}>
                  {result.decision === 'allow' ? 'Release ALLOWED — all checks passed' : `Release BLOCKED — ${result.failed.length} failure${result.failed.length>1?'s':''}`}
                </div>
              </div>

              {result.decision === 'allow' && (
                <button className="btn btn-success" style={{width:'100%'}} onClick={handleRelease}>
                  <ShieldCheck size={14}/> Approve batch release
                </button>
              )}

              {result.decision === 'block' && (
                <div>
                  {canOverride && !overrideMode && (
                    <button className="btn" style={{width:'100%',borderColor:'#E53E3E',color:'#E53E3E'}} onClick={() => setOverrideMode(true)}>
                      Override (QA Manager justification required)
                    </button>
                  )}
                  {overrideMode && (
                    <div style={{marginTop:8}}>
                      <div style={{fontSize:11,fontWeight:600,color:'#991B1B',marginBottom:6}}>⚠ Override justification (permanent audit record)</div>
                      <textarea className="input" rows={3} style={{height:'auto',padding:'8px 10px',marginBottom:8}} value={overrideText} onChange={e=>setOverrideText(e.target.value)} placeholder="Explain why this batch should be released despite compliance failures (min. 20 characters)…"/>
                      <div style={{display:'flex',gap:8}}>
                        <button className="btn" onClick={() => setOverrideMode(false)}>Cancel</button>
                        <button className="btn btn-danger" onClick={handleOverride}>Confirm override & release</button>
                      </div>
                    </div>
                  )}
                  {!canOverride && (
                    <div style={{fontSize:11,color:'#9ca3af',marginTop:8,textAlign:'center'}}>Only QA Manager can override a blocked release.</div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
