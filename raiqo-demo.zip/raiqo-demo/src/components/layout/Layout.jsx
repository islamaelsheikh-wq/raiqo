// src/components/layout/Layout.jsx
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { logOut } from '../../services/auth'
import { ROLES } from '../../services/auth'
import { Bell, LayoutDashboard, FileText, BadgeCheck, GitBranch, RotateCcw, ShieldCheck, Search, Building2, MapPin, BarChart, Users, LogOut, ChevronDown, Menu, X, ClipboardList, Send, Eye } from 'lucide-react'

const NAV = [
  { section:'Overview', items:[
    { to:'/', label:'Dashboard', icon:LayoutDashboard, exact:true },
    { to:'/notifications', label:'Alerts & notifications', icon:Bell, badge:'alerts' },
  ]},
  { section:'Regulatory', items:[
    { to:'/updates', label:'RA updates', icon:FileText, badge:'updates' },
    { to:'/registrations', label:'Registrations', icon:Certificate },
    { to:'/variations', label:'Variations', icon:GitBranch },
  ]},
  { section:'Quality', items:[
    { to:'/batch', label:'Batch release gate', icon:ShieldCheck, badge:'batch' },
  ]},
  { section:'Master data', items:[
    { to:'/vendors', label:'Vendors & AVL', icon:Building2 },
  ]},
  { section:'Analytics', items:[
    { to:'/reports', label:'Reports', icon:BarChart },
  ]},
]

const ROLE_COLOR = {
  app_admin:'#E53E3E', regulatory_director:'#7B61FF',
  ra_manager:'#4CC9F0', ra_officer:'#4CC9F0',
  qa_manager:'#059669', qa_officer:'#059669',
  supply_chain:'#D97706', procurement_officer:'#D97706',
  manufacturing_manager:'#6366F1', medical_affairs:'#EC4899',
  executive:'#9CA3AF',
}

export default function Layout() {
  const { profile } = useAuth()
  const navigate = useNavigate()
  const [sideOpen, setSideOpen] = useState(true)
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  async function handleLogout() {
    await logOut()
    navigate('/signin')
  }

  const isAdmin = profile?.role === 'app_admin'

  return (
    <div style={{display:'flex', height:'100vh', overflow:'hidden'}}>
      {/* Sidebar */}
      <aside style={{
        width: sideOpen ? 210 : 0,
        minWidth: sideOpen ? 210 : 0,
        background:'#0A0E1A',
        display:'flex', flexDirection:'column',
        transition:'width 0.2s, min-width 0.2s',
        overflow:'hidden', flexShrink:0,
      }}>
        {/* Logo */}
        <div style={{padding:'16px 14px 12px', borderBottom:'0.5px solid rgba(255,255,255,0.06)', display:'flex', alignItems:'center', gap:8}}>
          <svg width="22" height="22" viewBox="0 0 80 80" fill="none">
            <path d="M40 4 A36 36 0 0 1 76 40" stroke="#4CC9F0" strokeWidth="6" strokeLinecap="round" fill="none"/>
            <path d="M76 40 A36 36 0 0 1 40 76" stroke="#7B61FF" strokeWidth="6" strokeLinecap="round" fill="none"/>
            <path d="M40 76 A36 36 0 1 1 40 4" stroke="rgba(255,255,255,0.15)" strokeWidth="6" strokeLinecap="round" fill="none"/>
            <circle cx="40" cy="40" r="6" fill="#7B61FF"/>
            <circle cx="40" cy="40" r="3" fill="#4CC9F0"/>
          </svg>
          <div style={{fontSize:17,fontWeight:800,letterSpacing:'-0.04em',whiteSpace:'nowrap'}}>
            <span style={{color:'#4CC9F0'}}>RA</span><span style={{color:'#7B61FF'}}>IQ</span><span style={{color:'#fff'}}>O</span>
          </div>
        </div>

        {/* Nav */}
        <nav style={{flex:1, overflowY:'auto', padding:'8px 6px'}}>
          {NAV.map(group => (
            <div key={group.section}>
              <div style={{fontSize:9,fontWeight:600,letterSpacing:'.1em',textTransform:'uppercase',color:'rgba(255,255,255,0.22)',padding:'8px 8px 3px'}}>{group.section}</div>
              {group.items.map(item => (
                <NavLink key={item.to} to={item.to} end={item.exact}
                  style={({isActive}) => ({
                    display:'flex', alignItems:'center', gap:9, padding:'7px 9px',
                    borderRadius:7, marginBottom:1, textDecoration:'none',
                    color: isActive ? '#fff' : 'rgba(255,255,255,0.48)',
                    background: isActive ? 'rgba(123,97,255,0.22)' : 'transparent',
                    fontSize:12, fontWeight: isActive ? 500 : 400,
                    transition:'all 0.1s',
                  })}>
                  {({isActive}) => (<>
                    <item.icon size={14} color={isActive ? '#7B61FF' : 'rgba(255,255,255,0.28)'} />
                    <span style={{whiteSpace:'nowrap'}}>{item.label}</span>
                  </>)}
                </NavLink>
              ))}
            </div>
          ))}
          {isAdmin && (
            <div>
              <div style={{fontSize:9,fontWeight:600,letterSpacing:'.1em',textTransform:'uppercase',color:'rgba(255,255,255,0.22)',padding:'8px 8px 3px'}}>System</div>
              <NavLink to="/admin"
                style={({isActive}) => ({
                  display:'flex', alignItems:'center', gap:9, padding:'7px 9px',
                  borderRadius:7, textDecoration:'none',
                  color: isActive ? '#fff' : 'rgba(255,255,255,0.48)',
                  background: isActive ? 'rgba(229,62,62,0.2)' : 'transparent',
                  fontSize:12,
                })}>
                {({isActive}) => (<>
                  <Users size={14} color={isActive ? '#E53E3E' : 'rgba(255,255,255,0.28)'} />
                  <span>Admin panel</span>
                </>)}
              </NavLink>
            </div>
          )}
        </nav>

        {/* User */}
        <div style={{padding:'10px 12px', borderTop:'0.5px solid rgba(255,255,255,0.06)'}}>
          <div style={{display:'flex', alignItems:'center', gap:8, cursor:'pointer'}} onClick={() => setUserMenuOpen(o => !o)}>
            <div style={{width:28,height:28,borderRadius:'50%',background: ROLE_COLOR[profile?.role]||'#7B61FF',display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,color:'#fff',flexShrink:0}}>
              {profile?.displayName?.slice(0,2).toUpperCase() || 'U?'}
            </div>
            <div style={{flex:1, overflow:'hidden'}}>
              <div style={{fontSize:11,fontWeight:500,color:'#fff',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{profile?.displayName}</div>
              <div style={{fontSize:9,color:'rgba(255,255,255,0.3)'}}>{ROLES[profile?.role]}</div>
            </div>
            <ChevronDown size={12} color="rgba(255,255,255,0.3)" />
          </div>
          {userMenuOpen && (
            <div style={{marginTop:8, background:'rgba(255,255,255,0.06)', borderRadius:8, overflow:'hidden'}}>
              <button onClick={() => { navigate('/change-password'); setUserMenuOpen(false) }}
                style={{width:'100%',display:'flex',alignItems:'center',gap:8,padding:'8px 10px',background:'none',border:'none',color:'rgba(255,255,255,0.6)',fontSize:12,cursor:'pointer',textAlign:'left'}}>
                Change password
              </button>
              <button onClick={handleLogout}
                style={{width:'100%',display:'flex',alignItems:'center',gap:8,padding:'8px 10px',background:'none',border:'none',color:'#fca5a5',fontSize:12,cursor:'pointer',textAlign:'left'}}>
                <LogOut size={13}/> Sign out
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Main */}
      <div style={{flex:1, display:'flex', flexDirection:'column', overflow:'hidden', minWidth:0}}>
        {/* Top bar */}
        <header style={{height:46,background:'#fff',borderBottom:'0.5px solid rgba(0,0,0,0.08)',display:'flex',alignItems:'center',padding:'0 16px',gap:10,flexShrink:0}}>
          <button onClick={() => setSideOpen(o => !o)} style={{background:'none',border:'none',color:'#6b7280',cursor:'pointer',padding:4,borderRadius:6,display:'flex',alignItems:'center'}}>
            {sideOpen ? <X size={16}/> : <Menu size={16}/>}
          </button>
          <div style={{flex:1, display:'flex', alignItems:'center', gap:8}}>
            <div style={{display:'flex',alignItems:'center',gap:6,background:'#f9fafb',border:'0.5px solid #e5e7eb',borderRadius:8,padding:'0 10px',height:30,width:200}}>
              <Search size={12} color="#9ca3af"/>
              <input placeholder="Search products, CCF…" style={{border:'none',background:'transparent',fontSize:12,color:'#374151',outline:'none',width:'100%'}}/>
            </div>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:6}}>
            <div style={{padding:'2px 10px',borderRadius:20,background:ROLE_COLOR[profile?.role]+'20',color:ROLE_COLOR[profile?.role]||'#7B61FF',fontSize:10,fontWeight:600}}>
              {ROLES[profile?.role]}
            </div>
          </div>
        </header>

        {/* Content */}
        <main style={{flex:1, overflowY:'auto', padding:'1.25rem 1.5rem'}}>
          <Outlet />
        </main>
      </div>
    </div>
  )
}
