// src/components/dashboard/Dashboard.jsx
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { SAMPLE_REGISTRATIONS, SAMPLE_RA_UPDATES, SAMPLE_BATCHES, PRODUCTS, MARKETS } from '../../data/sampleData'
import { AlertTriangle, CheckCircle, Clock, TrendingUp, Shield, RefreshCw, FileText } from 'lucide-react'

const STATUS_COLOR = { active:'#059669', review:'#D97706', expired:'#E53E3E', renewal_due:'#D97706', pending:'#7B61FF', blocked:'#E53E3E', query:'#E53E3E' }

const MAP_COUNTRIES = [
  { id:'uae', name:'UAE', auth:'MOHAP', regs:28, status:'active', x:312, y:120, w:22, h:14, label:'UAE' },
  { id:'ksa', name:'Saudi Arabia', auth:'SFDA', regs:24, status:'active', x:278, y:116, w:30, h:24, label:'KSA' },
  { id:'jor', name:'Jordan', auth:'JFDA', regs:14, status:'review', x:268, y:106, w:18, h:14, label:'JOR' },
  { id:'kwt', name:'Kuwait', auth:'MOH-KWT', regs:12, status:'active', x:298, y:110, w:16, h:12, label:'KWT' },
  { id:'bah', name:'Bahrain', auth:'NHRA', regs:10, status:'review', x:316, y:112, w:12, h:9, label:'BAH' },
  { id:'omn', name:'Oman', auth:'MOPH', regs:9, status:'active', x:328, y:124, w:18, h:18, label:'OMN' },
  { id:'qat', name:'Qatar', auth:'MOPH-Q', regs:7, status:'pending', x:310, y:128, w:10, h:10 },
  { id:'egy', name:'Egypt', auth:'ECCA', regs:11, status:'active', x:256, y:118, w:22, h:18, label:'EGY' },
  { id:'ird', name:'Iraq', auth:'MOH', regs:5, status:'query', x:280, y:100, w:20, h:16, label:'IRQ' },
  { id:'leb', name:'Lebanon', auth:'MOH-LB', regs:4, status:'query', x:268, y:104, w:12, h:10 },
  { id:'syr', name:'Syria', auth:'MOH-SY', regs:6, status:'review', x:272, y:95, w:16, h:12 },
  { id:'ind', name:'India', auth:'CDSCO', regs:8, status:'active', x:368, y:118, w:26, h:28, label:'IND' },
  { id:'pak', name:'Pakistan', auth:'DRAP', regs:5, status:'review', x:344, y:112, w:20, h:18, label:'PAK' },
  { id:'de', name:'Germany', auth:'BfArM', regs:6, status:'active', x:228, y:68, w:16, h:12, label:'GER' },
  { id:'fr', name:'France', auth:'ANSM', regs:5, status:'active', x:210, y:74, w:16, h:12, label:'FRA' },
  { id:'us', name:'United States', auth:'FDA', regs:3, status:'pending', x:72, y:98, w:56, h:38, label:'USA' },
]

function StatusPill({ status }) {
  const map = { active:['Active','pill-active'], blocked:['Blocked','pill-blocked'], review:['Under review','pill-review'], renewal_due:['Renewal due','pill-review'], expired:['Expired','pill-expired'], pending:['Pending','pill-pending'], query:['Query','pill-blocked'], implemented:['Implemented','pill-active'], approved:['Approved','pill-active'], submitted:['Submitted','pill-pending'], qa_pending:['QA Pending','pill-review'], qa_approved:['QA Approved','pill-active'], under_review:['Under review','pill-review'] }
  const [label, cls] = map[status] || [status, 'pill-pending']
  return <span className={`pill ${cls}`}>{label}</span>
}

export default function Dashboard() {
  const navigate = useNavigate()
  const [hoveredCountry, setHoveredCountry] = useState(null)
  const [tooltip, setTooltip] = useState({ visible:false, x:0, y:0, data:null })

  const blockedBatches = SAMPLE_BATCHES.filter(b => b.status === 'blocked').length
  const criticalUpdates = SAMPLE_RA_UPDATES.filter(u => u.priority === 'critical' && u.status !== 'implemented').length
  const renewalsDue = SAMPLE_REGISTRATIONS.filter(r => r.status === 'renewal_due' || r.status === 'expired').length
  const activeRegs = SAMPLE_REGISTRATIONS.filter(r => r.status === 'active').length

  const mapFill = { active:'#059669', review:'#D97706', query:'#E53E3E', pending:'#4CC9F0' }

  function handleMapMouseMove(e, country) {
    const rect = e.currentTarget.closest('svg').getBoundingClientRect()
    setTooltip({ visible:true, x: e.clientX - rect.left + 12, y: e.clientY - rect.top - 10, data: country })
  }

  const recentAlerts = [
    { type:'critical', text:'Batch VLX-2026-047 BLOCKED', sub:'Veloxin · UAE · API vendor not approved', time:'2h ago' },
    { type:'warn', text:'JFDA query overdue — response needed', sub:'Claritex Syrup · Jordan · 5 days past due', time:'4h ago' },
    { type:'warn', text:'Registration renewal due in 38 days', sub:'Medobal 10mg · MOHAP · UAE', time:'1d ago' },
    { type:'info', text:'New RA update submitted for QA review', sub:'Veloxin 500mg · API supplier change', time:'3h ago' },
    { type:'info', text:'Price revision implemented', sub:'Nexofen 400mg · Kuwait · CCF/2026/0101', time:'1d ago' },
  ]

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Global overview</div>
          <div className="page-sub">Regulatory intelligence across all markets</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <span style={{padding:'4px 12px',borderRadius:20,background:'rgba(123,97,255,0.1)',color:'#7B61FF',fontSize:11,fontWeight:500}}>GCC + Levant</span>
          <span style={{padding:'4px 12px',borderRadius:20,background:'rgba(123,97,255,0.1)',color:'#7B61FF',fontSize:11,fontWeight:500}}>2024 – 2026</span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid4" style={{marginBottom:'1rem'}}>
        {[
          { label:'Active registrations', value:activeRegs, sub:'8 markets', color:'#7B61FF', icon:CheckCircle },
          { label:'Critical updates', value:criticalUpdates, sub:'Action required', color:'#E53E3E', icon:AlertTriangle },
          { label:'Blocked batches', value:blockedBatches, sub:'Cannot release', color:'#E53E3E', icon:Shield },
          { label:'Renewals due', value:renewalsDue, sub:'Within 90 days', color:'#D97706', icon:Clock },
        ].map(k => (
          <div key={k.label} className="card" style={{padding:'14px 16px'}}>
            <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between'}}>
              <div style={{flex:1}}>
                <div style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.07em',color:'#6b7280',marginBottom:4}}>{k.label}</div>
                <div style={{fontSize:26,fontWeight:800,letterSpacing:'-0.02em',color:k.color,lineHeight:1}}>{k.value}</div>
                <div style={{fontSize:10,color:'#9ca3af',marginTop:4}}>{k.sub}</div>
              </div>
              <div style={{width:32,height:32,borderRadius:8,background:k.color+'15',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                <k.icon size={16} color={k.color}/>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Compliance + Approval */}
      <div className="grid4" style={{marginBottom:'1rem'}}>
        {[
          { label:'Approval rate', value:'92%', sub:'↑ 4% vs last year', color:'#059669' },
          { label:'Compliance score', value:'94%', sub:'On track', color:'#059669' },
          { label:'Pending queries', value:'47', sub:'12 due this week', color:'#D97706' },
          { label:'Open variations', value:'6', sub:'4 awaiting impl.', color:'#7B61FF' },
        ].map(k => (
          <div key={k.label} className="card" style={{padding:'12px 14px'}}>
            <div style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.07em',color:'#6b7280',marginBottom:4}}>{k.label}</div>
            <div style={{fontSize:22,fontWeight:700,color:k.color,lineHeight:1}}>{k.value}</div>
            <div style={{fontSize:10,color:'#9ca3af',marginTop:3}}>{k.sub}</div>
          </div>
        ))}
      </div>

      {/* Map + Alerts */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 220px',gap:'1rem',marginBottom:'1rem'}}>
        {/* World Map */}
        <div className="card" style={{padding:12}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8}}>
            <div style={{fontSize:12,fontWeight:600}}>Global submission & registration tracking</div>
            <div style={{display:'flex',gap:10}}>
              {[['#059669','Approved'],['#D97706','Under review'],['#E53E3E','Query/Issue'],['#4CC9F0','Pending']].map(([c,l]) => (
                <div key={l} style={{display:'flex',alignItems:'center',gap:4,fontSize:9,color:'#6b7280'}}>
                  <div style={{width:7,height:7,borderRadius:'50%',background:c}}/>
                  {l}
                </div>
              ))}
            </div>
          </div>
          <div style={{position:'relative'}}>
            <svg viewBox="0 0 520 220" style={{width:'100%',height:'auto',cursor:'pointer'}}>
              {/* Ocean background */}
              <rect width="520" height="220" fill="#EEF4FF" rx="6"/>
              {/* Continent outlines — simplified */}
              <path d="M40 60 Q80 40 140 50 Q180 55 200 70 Q220 85 210 120 Q200 145 190 160 Q175 185 160 190 Q140 195 125 180 Q110 165 115 140 Q120 115 100 100 Q75 85 50 90 Q30 90 30 75 Z" fill="#f0f4ff" opacity="0.6"/>
              <path d="M200 55 Q260 45 310 60 Q350 70 380 80 Q420 90 440 110 Q450 130 440 155 Q430 175 410 180 Q390 182 370 170 Q350 160 355 140 Q360 120 340 105 Q315 90 295 100 Q275 108 265 125 Q258 140 255 155 Q250 170 240 178 Q220 185 205 175 Q190 165 190 145 Q188 125 195 110 Q202 95 200 80 Z" fill="#f0f4ff" opacity="0.6"/>

              {MAP_COUNTRIES.map(c => (
                <g key={c.id}
                  onMouseMove={e => handleMapMouseMove(e, c)}
                  onMouseLeave={() => setTooltip({visible:false})}
                  onClick={() => navigate('/registrations')}
                  style={{cursor:'pointer'}}>
                  <rect x={c.x} y={c.y} width={c.w} height={c.h} rx="2"
                    fill={mapFill[c.status] || '#9ca3af'}
                    opacity={hoveredCountry === c.id ? 1 : 0.85}
                    stroke="#fff" strokeWidth="0.5"
                  />
                  {c.label && c.w > 16 && (
                    <text x={c.x + c.w/2} y={c.y + c.h/2 + 1} textAnchor="middle" dominantBaseline="central"
                      fontSize={c.w > 30 ? 7 : 5.5} fill="#fff" fontWeight="700">{c.label}</text>
                  )}
                </g>
              ))}

              {/* Stats overlay */}
              <rect x="8" y="6" width="96" height="28" rx="4" fill="rgba(10,14,26,0.75)"/>
              <text x="14" y="18" fontSize="8" fill="#4CC9F0" fontWeight="600">142 registrations</text>
              <text x="14" y="28" fontSize="7" fill="rgba(255,255,255,0.55)">across 16 markets</text>

              {tooltip.visible && (
                <g transform={`translate(${Math.min(tooltip.x, 380)},${Math.max(tooltip.y - 30, 5)})`}>
                  <rect width="130" height="46" rx="4" fill="rgba(10,14,26,0.92)"/>
                  <text x="8" y="16" fontSize="9" fill="#4CC9F0" fontWeight="700">{tooltip.data?.name}</text>
                  <text x="8" y="28" fontSize="8" fill="rgba(255,255,255,0.7)">{tooltip.data?.regs} registrations</text>
                  <text x="8" y="40" fontSize="8" fill="rgba(255,255,255,0.45)">{tooltip.data?.auth}</text>
                </g>
              )}
            </svg>
          </div>
        </div>

        {/* Alerts */}
        <div className="card" style={{padding:0,overflow:'hidden'}}>
          <div style={{padding:'12px 14px',borderBottom:'0.5px solid rgba(0,0,0,0.07)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
            <div style={{fontSize:11,fontWeight:600}}>Critical alerts</div>
            <button onClick={() => navigate('/notifications')} style={{background:'none',border:'none',fontSize:10,color:'#7B61FF',cursor:'pointer'}}>View all →</button>
          </div>
          {recentAlerts.map((a,i) => (
            <div key={i} style={{display:'flex',alignItems:'flex-start',gap:8,padding:'9px 14px',borderBottom:'0.5px solid rgba(0,0,0,0.05)'}}>
              <div style={{width:7,height:7,borderRadius:'50%',background:a.type==='critical'?'#E53E3E':a.type==='warn'?'#D97706':'#7B61FF',flexShrink:0,marginTop:3}}/>
              <div style={{flex:1}}>
                <div style={{fontSize:11,fontWeight:500,lineHeight:1.3}}>{a.text}</div>
                <div style={{fontSize:10,color:'#9ca3af',marginTop:2}}>{a.sub}</div>
                <div style={{fontSize:9,color:'#d1d5db',marginTop:1}}>{a.time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent RA Updates + Registrations */}
      <div className="grid2">
        <div className="card" style={{padding:0,overflow:'hidden'}}>
          <div style={{padding:'12px 14px',borderBottom:'0.5px solid rgba(0,0,0,0.07)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
            <div style={{fontSize:11,fontWeight:600}}>Recent RA updates</div>
            <button onClick={() => navigate('/updates')} style={{background:'none',border:'none',fontSize:10,color:'#7B61FF',cursor:'pointer'}}>View all →</button>
          </div>
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead><tr>
              <th style={{padding:'7px 12px',fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.06em',color:'#9ca3af',borderBottom:'0.5px solid rgba(0,0,0,0.06)',textAlign:'left'}}>Product</th>
              <th style={{padding:'7px 12px',fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.06em',color:'#9ca3af',borderBottom:'0.5px solid rgba(0,0,0,0.06)',textAlign:'left'}}>Type</th>
              <th style={{padding:'7px 12px',fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.06em',color:'#9ca3af',borderBottom:'0.5px solid rgba(0,0,0,0.06)',textAlign:'left'}}>Status</th>
            </tr></thead>
            <tbody>
              {SAMPLE_RA_UPDATES.slice(0,5).map(u => {
                const prod = PRODUCTS.find(p => p.id === u.productId)
                return (
                  <tr key={u.id} onClick={() => navigate('/updates')} style={{cursor:'pointer'}}>
                    <td style={{padding:'8px 12px',borderBottom:'0.5px solid rgba(0,0,0,0.04)',fontSize:12}}>{prod?.name || u.productId}</td>
                    <td style={{padding:'8px 12px',borderBottom:'0.5px solid rgba(0,0,0,0.04)',fontSize:11,color:'#6b7280'}}>{u.subcategory}</td>
                    <td style={{padding:'8px 12px',borderBottom:'0.5px solid rgba(0,0,0,0.04)'}}><StatusPill status={u.status}/></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="card" style={{padding:0,overflow:'hidden'}}>
          <div style={{padding:'12px 14px',borderBottom:'0.5px solid rgba(0,0,0,0.07)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
            <div style={{fontSize:11,fontWeight:600}}>Registration status</div>
            <button onClick={() => navigate('/registrations')} style={{background:'none',border:'none',fontSize:10,color:'#7B61FF',cursor:'pointer'}}>View all →</button>
          </div>
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead><tr>
              <th style={{padding:'7px 12px',fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.06em',color:'#9ca3af',borderBottom:'0.5px solid rgba(0,0,0,0.06)',textAlign:'left'}}>Reg. No.</th>
              <th style={{padding:'7px 12px',fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.06em',color:'#9ca3af',borderBottom:'0.5px solid rgba(0,0,0,0.06)',textAlign:'left'}}>Market</th>
              <th style={{padding:'7px 12px',fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.06em',color:'#9ca3af',borderBottom:'0.5px solid rgba(0,0,0,0.06)',textAlign:'left'}}>Status</th>
            </tr></thead>
            <tbody>
              {SAMPLE_REGISTRATIONS.slice(0,5).map(r => (
                <tr key={r.id} onClick={() => navigate('/registrations')} style={{cursor:'pointer'}}>
                  <td style={{padding:'8px 12px',borderBottom:'0.5px solid rgba(0,0,0,0.04)'}}><span className="mono">{r.regNumber.slice(-8)}</span></td>
                  <td style={{padding:'8px 12px',borderBottom:'0.5px solid rgba(0,0,0,0.04)',fontSize:12}}>{r.market} · {r.authority}</td>
                  <td style={{padding:'8px 12px',borderBottom:'0.5px solid rgba(0,0,0,0.04)'}}><StatusPill status={r.status}/></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
