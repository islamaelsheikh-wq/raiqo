// src/components/auth/SignIn.jsx
import { useState } from 'react'
import { signIn } from '../../services/auth'
import { useAuth } from '../../contexts/AuthContext'

export default function SignIn() {
  const [userId, setUserId] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { setProfile } = useAuth()

  async function handleSubmit(e) {
    e.preventDefault()
    if (!userId.trim() || !password) return
    setLoading(true); setError('')
    try {
      const { profile } = await signIn(userId.trim(), password)
      setProfile(profile)
    } catch (err) {
      setError(err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password'
        ? 'Invalid user ID or password.' : err.message || 'Sign in failed.')
    } finally { setLoading(false) }
  }

  return (
    <div style={{ minHeight:'100vh', background:'#0A0E1A', display:'flex', alignItems:'center', justifyContent:'center', padding:'1rem' }}>
      <div style={{ width:'100%', maxWidth:'400px' }}>

        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:'2rem' }}>
          <svg width="52" height="52" viewBox="0 0 80 80" fill="none" style={{margin:'0 auto 12px', display:'block'}}>
            <path d="M40 4 A36 36 0 0 1 76 40" stroke="#4CC9F0" strokeWidth="5" strokeLinecap="round" fill="none"/>
            <path d="M76 40 A36 36 0 0 1 40 76" stroke="#7B61FF" strokeWidth="5" strokeLinecap="round" fill="none"/>
            <path d="M40 76 A36 36 0 1 1 40 4" stroke="rgba(255,255,255,0.15)" strokeWidth="5" strokeLinecap="round" fill="none"/>
            <circle cx="40" cy="40" r="6" fill="#7B61FF"/>
            <circle cx="40" cy="40" r="3" fill="#4CC9F0"/>
          </svg>
          <div style={{ fontSize:28, fontWeight:800, letterSpacing:'-0.04em', color:'#fff' }}>
            <span style={{color:'#4CC9F0'}}>RA</span><span style={{color:'#7B61FF'}}>IQ</span><span style={{color:'#fff'}}>O</span>
          </div>
          <div style={{ fontSize:12, color:'rgba(255,255,255,0.4)', marginTop:4, letterSpacing:'0.08em', textTransform:'uppercase' }}>
            Regulatory Intelligence Platform
          </div>
        </div>

        {/* Card */}
        <div style={{ background:'rgba(255,255,255,0.04)', border:'0.5px solid rgba(255,255,255,0.1)', borderRadius:14, padding:'1.75rem' }}>
          <div style={{ fontSize:15, fontWeight:600, color:'#fff', marginBottom:6 }}>Sign in to your account</div>
          <div style={{ fontSize:12, color:'rgba(255,255,255,0.4)', marginBottom:1.5+'rem' }}>Use your assigned user ID and password</div>

          <form onSubmit={handleSubmit} style={{display:'flex', flexDirection:'column', gap:14}}>
            <div>
              <label style={{ fontSize:10, fontWeight:600, textTransform:'uppercase', letterSpacing:'0.07em', color:'rgba(255,255,255,0.4)', display:'block', marginBottom:5 }}>User ID</label>
              <input
                value={userId} onChange={e => setUserId(e.target.value)}
                placeholder="e.g. RM-001 or QM-001"
                autoComplete="username" required
                style={{ width:'100%', height:38, background:'rgba(255,255,255,0.06)', border:'0.5px solid rgba(255,255,255,0.15)', borderRadius:8, padding:'0 12px', fontSize:13, color:'#fff', outline:'none' }}
                onFocus={e => e.target.style.borderColor='#7B61FF'}
                onBlur={e => e.target.style.borderColor='rgba(255,255,255,0.15)'}
              />
            </div>
            <div>
              <label style={{ fontSize:10, fontWeight:600, textTransform:'uppercase', letterSpacing:'0.07em', color:'rgba(255,255,255,0.4)', display:'block', marginBottom:5 }}>Password</label>
              <input type="password"
                value={password} onChange={e => setPassword(e.target.value)}
                placeholder="Enter your password"
                autoComplete="current-password" required
                style={{ width:'100%', height:38, background:'rgba(255,255,255,0.06)', border:'0.5px solid rgba(255,255,255,0.15)', borderRadius:8, padding:'0 12px', fontSize:13, color:'#fff', outline:'none' }}
                onFocus={e => e.target.style.borderColor='#7B61FF'}
                onBlur={e => e.target.style.borderColor='rgba(255,255,255,0.15)'}
              />
            </div>

            {error && (
              <div style={{ background:'rgba(229,62,62,0.15)', border:'0.5px solid rgba(229,62,62,0.4)', borderRadius:8, padding:'8px 12px', fontSize:12, color:'#fca5a5' }}>
                {error}
              </div>
            )}

            <button type="submit" disabled={loading}
              style={{ height:40, background:'#7B61FF', color:'#fff', border:'none', borderRadius:8, fontSize:13, fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8, marginTop:4 }}>
              {loading ? <><div style={{width:16,height:16,border:'2px solid rgba(255,255,255,0.3)',borderTopColor:'#fff',borderRadius:'50%',animation:'spin 0.7s linear infinite'}}/>Signing in…</> : 'Sign in'}
            </button>
          </form>
        </div>

        {/* Demo hint */}
        <div style={{ marginTop:16, background:'rgba(76,201,240,0.08)', border:'0.5px solid rgba(76,201,240,0.2)', borderRadius:10, padding:'12px 14px' }}>
          <div style={{ fontSize:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'0.08em', color:'#4CC9F0', marginBottom:6 }}>Demo credentials</div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:4 }}>
            {[['ADMIN-001','App Admin'],['QM-001','QA Manager'],['RM-001','RA Manager'],['EX-001','Executive']].map(([id,role]) => (
              <div key={id} onClick={() => setUserId(id)}
                style={{ fontSize:11, color:'rgba(255,255,255,0.5)', cursor:'pointer', padding:'3px 6px', borderRadius:5, border:'0.5px solid rgba(255,255,255,0.08)' }}
                onMouseEnter={e=>e.currentTarget.style.background='rgba(255,255,255,0.06)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <span style={{color:'rgba(255,255,255,0.75)', fontWeight:500}}>{id}</span> · {role}
              </div>
            ))}
          </div>
          <div style={{fontSize:10,color:'rgba(255,255,255,0.3)',marginTop:6}}>Default password: <span style={{color:'rgba(255,255,255,0.5)',fontFamily:'monospace'}}>Raiqo@2026</span></div>
        </div>

        <div style={{ textAlign:'center', marginTop:16, fontSize:11, color:'rgba(255,255,255,0.2)' }}>
          RAIQO Demo v1.0 · Fictional data only · © 2026
        </div>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  )
}
