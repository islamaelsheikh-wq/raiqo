// src/components/auth/ChangePassword.jsx
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { changePassword } from '../../services/auth'
import { useAuth } from '../../contexts/AuthContext'
import { doc, updateDoc } from 'firebase/firestore'
import { db } from '../../services/firebase'

export default function ChangePassword() {
  const { user, profile, setProfile } = useAuth()
  const navigate = useNavigate()
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const isForced = !profile?.passwordChanged

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    if (next.length < 8) return setError('New password must be at least 8 characters.')
    if (next !== confirm) return setError('Passwords do not match.')
    if (next === current) return setError('New password must differ from current password.')
    setLoading(true)
    try {
      await changePassword(current, next)
      if (user) {
        await updateDoc(doc(db, 'users', user.uid), { passwordChanged: true })
        setProfile(p => ({ ...p, passwordChanged: true }))
      }
      navigate('/', { replace: true })
    } catch (err) {
      setError(err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential'
        ? 'Current password is incorrect.' : err.message || 'Failed to change password.')
    } finally { setLoading(false) }
  }

  return (
    <div style={{ minHeight:'100vh', background:'#0A0E1A', display:'flex', alignItems:'center', justifyContent:'center', padding:'1rem' }}>
      <div style={{ width:'100%', maxWidth:'400px' }}>
        <div style={{ textAlign:'center', marginBottom:'1.5rem' }}>
          <svg width="40" height="40" viewBox="0 0 80 80" fill="none" style={{margin:'0 auto 10px',display:'block'}}>
            <path d="M40 4 A36 36 0 0 1 76 40" stroke="#4CC9F0" strokeWidth="5" strokeLinecap="round" fill="none"/>
            <path d="M76 40 A36 36 0 0 1 40 76" stroke="#7B61FF" strokeWidth="5" strokeLinecap="round" fill="none"/>
            <path d="M40 76 A36 36 0 1 1 40 4" stroke="rgba(255,255,255,0.15)" strokeWidth="5" strokeLinecap="round" fill="none"/>
            <circle cx="40" cy="40" r="6" fill="#7B61FF"/>
            <circle cx="40" cy="40" r="3" fill="#4CC9F0"/>
          </svg>
          <div style={{fontSize:22,fontWeight:800,letterSpacing:'-0.04em',color:'#fff'}}>
            <span style={{color:'#4CC9F0'}}>RA</span><span style={{color:'#7B61FF'}}>IQ</span><span style={{color:'#fff'}}>O</span>
          </div>
        </div>

        <div style={{background:'rgba(255,255,255,0.04)',border:'0.5px solid rgba(255,255,255,0.1)',borderRadius:14,padding:'1.75rem'}}>
          {isForced && (
            <div style={{background:'rgba(217,119,6,0.15)',border:'0.5px solid rgba(217,119,6,0.4)',borderRadius:8,padding:'10px 12px',fontSize:12,color:'#fcd34d',marginBottom:16}}>
              You must set a new password before continuing.
            </div>
          )}
          <div style={{fontSize:15,fontWeight:600,color:'#fff',marginBottom:4}}>
            {isForced ? 'Set your new password' : 'Change password'}
          </div>
          <div style={{fontSize:12,color:'rgba(255,255,255,0.4)',marginBottom:'1.25rem'}}>
            Welcome, {profile?.displayName || 'User'}. Choose a strong password.
          </div>

          <form onSubmit={handleSubmit} style={{display:'flex',flexDirection:'column',gap:12}}>
            {[
              { label:'Current password', val:current, set:setCurrent, ph:'Enter current password' },
              { label:'New password', val:next, set:setNext, ph:'At least 8 characters' },
              { label:'Confirm new password', val:confirm, set:setConfirm, ph:'Repeat new password' },
            ].map(({label,val,set,ph}) => (
              <div key={label}>
                <label style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'0.07em',color:'rgba(255,255,255,0.4)',display:'block',marginBottom:4}}>{label}</label>
                <input type="password" value={val} onChange={e=>set(e.target.value)} placeholder={ph} required
                  style={{width:'100%',height:38,background:'rgba(255,255,255,0.06)',border:'0.5px solid rgba(255,255,255,0.15)',borderRadius:8,padding:'0 12px',fontSize:13,color:'#fff',outline:'none'}}
                  onFocus={e=>e.target.style.borderColor='#7B61FF'}
                  onBlur={e=>e.target.style.borderColor='rgba(255,255,255,0.15)'}
                />
              </div>
            ))}

            {error && <div style={{background:'rgba(229,62,62,0.15)',border:'0.5px solid rgba(229,62,62,0.4)',borderRadius:8,padding:'8px 12px',fontSize:12,color:'#fca5a5'}}>{error}</div>}

            <button type="submit" disabled={loading}
              style={{height:40,background:'#7B61FF',color:'#fff',border:'none',borderRadius:8,fontSize:13,fontWeight:600,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:8,marginTop:4}}>
              {loading ? 'Saving…' : 'Set new password & continue'}
            </button>
          </form>
        </div>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  )
}
