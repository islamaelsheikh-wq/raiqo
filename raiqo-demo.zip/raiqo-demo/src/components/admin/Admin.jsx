// src/components/admin/Admin.jsx
import { useState, useEffect } from 'react'
import { collection, getDocs, doc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore'
import { createUserWithEmailAndPassword } from 'firebase/auth'
import { db, auth } from '../../services/firebase'
import { normalizeEmail, ROLES } from '../../services/auth'
import { DEMO_USERS } from '../../data/sampleData'
import { useAuth } from '../../contexts/AuthContext'
import { Plus, Users, Settings, Bell, Database } from 'lucide-react'

const ROLE_COLOR = { app_admin:'#E53E3E', regulatory_director:'#7B61FF', ra_manager:'#4CC9F0', ra_officer:'#4CC9F0', qa_manager:'#059669', qa_officer:'#059669', supply_chain:'#D97706', procurement_officer:'#D97706', manufacturing_manager:'#6366F1', medical_affairs:'#EC4899', executive:'#9CA3AF' }

export default function Admin() {
  const { profile } = useAuth()
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [activeTab, setActiveTab] = useState('users')
  const [msg, setMsg] = useState('')
  const [form, setForm] = useState({ userId:'', displayName:'', email:'', role:'ra_officer', department:'', password:'Raiqo@2026' })
  const [editWA, setEditWA] = useState(null)
  const [waForm, setWaForm] = useState({ whatsappPhone:'', whatsappApiKey:'' })

  useEffect(() => { loadUsers() }, [])

  async function loadUsers() {
    setLoading(true)
    try {
      const snap = await getDocs(collection(db, 'users'))
      setUsers(snap.docs.map(d => ({ id: d.id, ...d.data() })))
    } catch {
      setUsers(DEMO_USERS.map((u,i) => ({ id:`demo-${i}`, ...u })))
    }
    setLoading(false)
  }

  async function handleCreateUser(e) {
    e.preventDefault()
    try {
      const email = normalizeEmail(form.userId)
      const cred = await createUserWithEmailAndPassword(auth, email, form.password)
      await setDoc(doc(db, 'users', cred.user.uid), {
        userId: form.userId, displayName: form.displayName, email: form.email || email,
        role: form.role, department: form.department, status: 'active', passwordChanged: false,
        createdAt: serverTimestamp(), createdBy: profile?.userId || 'admin',
      })
      setMsg(`✓ User ${form.userId} created. They must change their password on first login.`)
      setShowForm(false)
      setForm({ userId:'', displayName:'', email:'', role:'ra_officer', department:'', password:'Raiqo@2026' })
      await loadUsers()
    } catch (err) {
      setMsg(`Error: ${err.message}`)
    }
    setTimeout(() => setMsg(''), 6000)
  }

  async function toggleUserStatus(user) {
    try {
      await updateDoc(doc(db, 'users', user.id), { status: user.status === 'active' ? 'inactive' : 'active' })
      await loadUsers()
    } catch { setUsers(u => u.map(x => x.id === user.id ? {...x, status: x.status==='active'?'inactive':'active'} : x)) }
  }

  async function saveWAConfig() {
    try {
      await updateDoc(doc(db, 'users', editWA.id), { whatsappPhone: waForm.whatsappPhone, whatsappApiKey: waForm.whatsappApiKey })
      setMsg('✓ WhatsApp configured for user.')
    } catch { setMsg('WhatsApp config saved (demo mode).') }
    setEditWA(null)
    setTimeout(() => setMsg(''), 4000)
  }

  async function seedDemoData() {
    setMsg('Seeding demo users to Firestore…')
    for (const u of DEMO_USERS) {
      try {
        const email = normalizeEmail(u.userId)
        const cred = await createUserWithEmailAndPassword(auth, email, 'Raiqo@2026')
        await setDoc(doc(db, 'users', cred.user.uid), { ...u, createdAt: serverTimestamp() })
      } catch {}
    }
    setMsg('✓ Demo users seeded. Default password: Raiqo@2026')
    await loadUsers()
    setTimeout(() => setMsg(''), 5000)
  }

  if (profile?.role !== 'app_admin') {
    return <div className="card" style={{textAlign:'center',padding:'3rem',color:'#9ca3af'}}>Admin access required.</div>
  }

  const tabs = [{ id:'users', label:'User management', icon:Users }, { id:'notif', label:'Notification config', icon:Bell }, { id:'system', label:'System', icon:Settings }]

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Admin panel</div><div className="page-sub">User management, roles, and system configuration</div></div>
        <button className="btn btn-primary" onClick={() => setShowForm(true)}><Plus size={13}/> Create user</button>
      </div>

      {msg && <div style={{background: msg.startsWith('✓')?'#D1FAE5':'#FEE2E2', border:'0.5px solid', borderColor: msg.startsWith('✓')?'#6EE7B7':'#FCA5A5', borderRadius:8, padding:'10px 14px', fontSize:12, fontWeight:500, color: msg.startsWith('✓')?'#065F46':'#991B1B', marginBottom:'1rem'}}>{msg}</div>}

      {/* Tabs */}
      <div style={{display:'flex',gap:4,marginBottom:'1rem'}}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className="btn" style={{ background: activeTab===t.id ? '#0A0E1A' : undefined, color: activeTab===t.id ? '#fff' : undefined, borderColor: activeTab===t.id ? '#0A0E1A' : undefined }}>
            <t.icon size={13}/> {t.label}
          </button>
        ))}
      </div>

      {activeTab === 'users' && (
        <div className="card" style={{padding:0,overflow:'hidden'}}>
          <div className="table-wrap">
            <table>
              <thead><tr>
                <th>User ID</th><th>Name</th><th>Role</th><th>Department</th>
                <th>Status</th><th>WhatsApp</th><th>Last login</th><th>Actions</th>
              </tr></thead>
              <tbody>
                {(loading ? DEMO_USERS.map((u,i)=>({id:`d${i}`,...u})) : users).map(u => (
                  <tr key={u.id}>
                    <td><span className="mono">{u.userId}</span></td>
                    <td style={{fontWeight:500}}>{u.displayName}</td>
                    <td>
                      <span style={{fontSize:10,fontWeight:600,padding:'2px 8px',borderRadius:20,background:(ROLE_COLOR[u.role]||'#9ca3af')+'20',color:ROLE_COLOR[u.role]||'#9ca3af'}}>
                        {ROLES[u.role]||u.role}
                      </span>
                    </td>
                    <td style={{color:'#6b7280'}}>{u.department}</td>
                    <td><span className={`pill ${u.status==='active'?'pill-active':'pill-blocked'}`}>{u.status}</span></td>
                    <td>
                      {u.whatsappPhone ? (
                        <span style={{fontSize:10,color:'#059669',fontWeight:500}}>✓ {u.whatsappPhone}</span>
                      ) : (
                        <button className="btn btn-sm" onClick={() => { setEditWA(u); setWaForm({whatsappPhone:'',whatsappApiKey:''}) }}>Configure</button>
                      )}
                    </td>
                    <td style={{color:'#9ca3af',fontSize:11}}>{u.lastLogin ? new Date(u.lastLogin?.seconds*1000).toLocaleDateString() : 'Never'}</td>
                    <td>
                      <div style={{display:'flex',gap:4}}>
                        <button className="btn btn-sm" onClick={() => toggleUserStatus(u)}
                          style={{color: u.status==='active'?'#E53E3E':'#059669', borderColor: u.status==='active'?'#E53E3E':'#059669'}}>
                          {u.status === 'active' ? 'Deactivate' : 'Activate'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'notif' && (
        <div className="card">
          <div style={{fontSize:13,fontWeight:600,marginBottom:12}}>Notification configuration</div>
          <div style={{background:'#FEF3C7',border:'0.5px solid #FCD34D',borderRadius:8,padding:'12px 14px',fontSize:12,marginBottom:16}}>
            <strong>WhatsApp (CallMeBot):</strong> Each user must first send "I allow callmebot to send me messages" to <strong>+34 644 60 49 16</strong> on WhatsApp. They will receive their personal API key. Then configure it below per user.
          </div>
          <div style={{background:'#EDE9FE',border:'0.5px solid #C4B5FD',borderRadius:8,padding:'12px 14px',fontSize:12,marginBottom:16}}>
            <strong>Email (EmailJS):</strong> Set up a free account at emailjs.com, create a Gmail service, and add credentials to your .env file. Emails send directly from the browser — no server needed.
          </div>
          <div style={{fontSize:11,color:'#6b7280',lineHeight:1.8}}>
            <div>• VITE_EMAILJS_SERVICE_ID — from EmailJS dashboard</div>
            <div>• VITE_EMAILJS_TEMPLATE_ID — create template with {{to_email}}, {{subject}}, {{message}} variables</div>
            <div>• VITE_EMAILJS_PUBLIC_KEY — from EmailJS account</div>
            <div>• VITE_DEMO_EMAIL — your Gmail address for demo notifications</div>
            <div>• VITE_DEMO_WA_PHONE — your phone number (with country code, no +)</div>
            <div>• VITE_DEMO_WA_APIKEY — your CallMeBot API key</div>
          </div>
        </div>
      )}

      {activeTab === 'system' && (
        <div className="card">
          <div style={{fontSize:13,fontWeight:600,marginBottom:12}}>System tools</div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
            <button className="btn" onClick={seedDemoData}><Database size={13}/> Seed demo users to Firebase</button>
          </div>
          <div style={{marginTop:16,fontSize:11,color:'#9ca3af',lineHeight:1.8}}>
            <div>App version: RAIQO Demo v1.0</div>
            <div>Data: Fictional sample data only — for proposal purposes</div>
            <div>Firebase project: {import.meta.env.VITE_FIREBASE_PROJECT_ID || 'Not configured'}</div>
          </div>
        </div>
      )}

      {/* Create user modal */}
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">Create new user</div>
            <form onSubmit={handleCreateUser} style={{display:'flex',flexDirection:'column',gap:12}}>
              <div className="grid2">
                <div><label className="label">User ID (login ID)</label><input className="input" value={form.userId} onChange={e=>setForm(f=>({...f,userId:e.target.value}))} placeholder="e.g. QO-003" required/></div>
                <div><label className="label">Full name</label><input className="input" value={form.displayName} onChange={e=>setForm(f=>({...f,displayName:e.target.value}))} placeholder="Full name" required/></div>
              </div>
              <div><label className="label">Contact email (for notifications)</label><input type="email" className="input" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} placeholder="user@company.com"/></div>
              <div className="grid2">
                <div><label className="label">Role</label>
                  <select className="select" value={form.role} onChange={e=>setForm(f=>({...f,role:e.target.value}))}>
                    {Object.entries(ROLES).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </div>
                <div><label className="label">Department</label>
                  <select className="select" value={form.department} onChange={e=>setForm(f=>({...f,department:e.target.value}))}>
                    {['Regulatory Affairs','Quality Assurance','Supply Chain','Procurement','Production','Medical Affairs','Executive Management','IT'].map(d => <option key={d}>{d}</option>)}
                  </select>
                </div>
              </div>
              <div><label className="label">Initial password</label><input className="input" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))} placeholder="Temporary password (user must change on login)" required/></div>
              <div style={{background:'#EDE9FE',borderRadius:8,padding:'10px 12px',fontSize:11,color:'#5B21B6'}}>
                User will be required to change this password on their first login.
              </div>
              <div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
                <button type="button" className="btn" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create user</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* WhatsApp config modal */}
      {editWA && (
        <div className="modal-overlay" onClick={() => setEditWA(null)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{maxWidth:420}}>
            <div className="modal-title">Configure WhatsApp — {editWA.displayName}</div>
            <div style={{background:'#F0FDF4',border:'0.5px solid #6EE7B7',borderRadius:8,padding:'10px 12px',fontSize:11,color:'#065F46',marginBottom:16}}>
              Ask {editWA.displayName} to send this message to <strong>+34 644 60 49 16</strong> on WhatsApp: <br/><em>"I allow callmebot to send me messages"</em><br/>They will receive their API key back on WhatsApp.
            </div>
            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              <div><label className="label">WhatsApp phone number (with country code, no +)</label><input className="input" value={waForm.whatsappPhone} onChange={e=>setWaForm(f=>({...f,whatsappPhone:e.target.value}))} placeholder="e.g. 971501234567"/></div>
              <div><label className="label">CallMeBot API key</label><input className="input" value={waForm.whatsappApiKey} onChange={e=>setWaForm(f=>({...f,whatsappApiKey:e.target.value}))} placeholder="API key from CallMeBot"/></div>
            </div>
            <div style={{display:'flex',gap:8,justifyContent:'flex-end',marginTop:16}}>
              <button className="btn" onClick={() => setEditWA(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={saveWAConfig}>Save WhatsApp config</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
