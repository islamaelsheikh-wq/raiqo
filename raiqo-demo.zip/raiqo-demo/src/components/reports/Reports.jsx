// src/components/reports/Reports.jsx
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts'

const COLORS = ['#059669','#D97706','#E53E3E','#7B61FF','#4CC9F0']

const marketData = [
  { market:'UAE', active:28, renewal:2, expired:1 },
  { market:'KSA', active:24, renewal:1, expired:0 },
  { market:'JOR', active:10, renewal:3, expired:1 },
  { market:'KWT', active:12, renewal:1, expired:0 },
  { market:'BAH', active:8, renewal:2, expired:1 },
  { market:'OMN', active:9, renewal:0, expired:0 },
]

const updateTypeData = [
  { name:'Variation', value:42 }, { name:'Renewal', value:18 },
  { name:'New Reg.', value:12 }, { name:'Price', value:15 }, { name:'License', value:8 },
]

const complianceTrend = [
  { month:'Jan', score:88 }, { month:'Feb', score:90 }, { month:'Mar', score:87 },
  { month:'Apr', score:91 }, { month:'May', score:93 }, { month:'Jun', score:94 },
]

export default function Reports() {
  return (
    <div>
      <div className="page-header"><div><div className="page-title">Reports & analytics</div><div className="page-sub">Regulatory compliance KPIs and trends</div></div></div>
      <div className="grid2" style={{marginBottom:'1rem'}}>
        <div className="card">
          <div style={{fontSize:12,fontWeight:600,marginBottom:12}}>Registrations by market</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={marketData} margin={{top:0,right:10,bottom:0,left:-20}}>
              <XAxis dataKey="market" tick={{fontSize:11}}/>
              <YAxis tick={{fontSize:11}}/>
              <Tooltip contentStyle={{fontSize:11,borderRadius:8,border:'0.5px solid #e5e7eb'}}/>
              <Bar dataKey="active" stackId="a" fill="#059669" name="Active" radius={[0,0,0,0]}/>
              <Bar dataKey="renewal" stackId="a" fill="#D97706" name="Renewal due"/>
              <Bar dataKey="expired" stackId="a" fill="#E53E3E" name="Expired" radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <div style={{fontSize:12,fontWeight:600,marginBottom:12}}>Updates by type (YTD)</div>
          <div style={{display:'flex',alignItems:'center',gap:16}}>
            <PieChart width={140} height={140}>
              <Pie data={updateTypeData} cx={65} cy={65} innerRadius={40} outerRadius={60} dataKey="value" stroke="none">
                {updateTypeData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
              </Pie>
            </PieChart>
            <div style={{flex:1}}>
              {updateTypeData.map((d,i) => (
                <div key={d.name} style={{display:'flex',alignItems:'center',gap:6,marginBottom:5}}>
                  <div style={{width:8,height:8,borderRadius:2,background:COLORS[i],flexShrink:0}}/>
                  <span style={{flex:1,fontSize:11}}>{d.name}</span>
                  <span style={{fontSize:11,fontWeight:600,color:'#374151'}}>{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="card">
        <div style={{fontSize:12,fontWeight:600,marginBottom:12}}>Compliance score trend (2026)</div>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={complianceTrend} margin={{top:4,right:10,bottom:0,left:-20}}>
            <XAxis dataKey="month" tick={{fontSize:11}}/>
            <YAxis domain={[80,100]} tick={{fontSize:11}}/>
            <Tooltip formatter={v => [`${v}%`,'Score']} contentStyle={{fontSize:11,borderRadius:8,border:'0.5px solid #e5e7eb'}}/>
            <Line type="monotone" dataKey="score" stroke="#7B61FF" strokeWidth={2} dot={{fill:'#7B61FF',r:3}}/>
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="grid4" style={{marginTop:'1rem'}}>
        {[['On-time submissions','87%','#059669'],['Avg. approval time','42 days','#7B61FF'],['Renewal on-time rate','94%','#059669'],['Override rate','2.1%','#D97706']].map(([l,v,c]) => (
          <div key={l} className="card" style={{padding:'14px 16px',textAlign:'center'}}>
            <div style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.07em',color:'#9ca3af',marginBottom:6}}>{l}</div>
            <div style={{fontSize:24,fontWeight:800,color:c}}>{v}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
