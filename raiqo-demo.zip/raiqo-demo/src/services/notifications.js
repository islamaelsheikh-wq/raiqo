// src/services/notifications.js
// Handles email (EmailJS) and WhatsApp (CallMeBot) notifications
// Both work when the app is closed via Firebase Cloud Functions trigger
// or directly from the client for real-time events

import emailjs from '@emailjs/browser'
import { db } from './firebase'
import { collection, addDoc, serverTimestamp } from 'firebase/firestore'

// ─── EmailJS config ─────────────────────────────────────────────
const EMAILJS_SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID || 'REPLACE_SERVICE_ID'
const EMAILJS_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID || 'REPLACE_TEMPLATE_ID'
const EMAILJS_PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY || 'REPLACE_PUBLIC_KEY'

// Initialize EmailJS
emailjs.init(EMAILJS_PUBLIC_KEY)

// ─── Send email notification ────────────────────────────────────
export async function sendEmailNotification({ to_email, to_name, subject, message, event_type, product_name, market }) {
  try {
    const templateParams = {
      to_email,
      to_name,
      subject,
      message,
      event_type: event_type || 'System Alert',
      product_name: product_name || 'N/A',
      market: market || 'N/A',
      app_name: 'RAIQO',
      timestamp: new Date().toLocaleString('en-GB'),
    }
    const result = await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, templateParams)
    await logNotification({ channel: 'email', to: to_email, subject, message, status: 'sent' })
    return { success: true, result }
  } catch (error) {
    await logNotification({ channel: 'email', to: to_email, subject, message, status: 'failed', error: error.text })
    return { success: false, error }
  }
}

// ─── Send WhatsApp via CallMeBot ────────────────────────────────
// Each user must activate CallMeBot once: send "I allow callmebot to send me messages"
// to +34 644 60 49 16 on WhatsApp, then use the API key they receive.
// Admin sets phone + apikey per user in the admin panel → stored in Firestore users doc.
export async function sendWhatsAppNotification({ phone, apiKey, message }) {
  if (!phone || !apiKey) return { success: false, error: 'No WhatsApp configured for user' }
  try {
    // CallMeBot free API — no backend needed, CORS-free via direct URL
    const encoded = encodeURIComponent(message)
    const url = `https://api.callmebot.com/whatsapp.php?phone=${phone}&text=${encoded}&apikey=${apiKey}`
    // Use no-cors fetch for CallMeBot (it doesn't need response body)
    await fetch(url, { mode: 'no-cors' })
    await logNotification({ channel: 'whatsapp', to: phone, subject: 'WhatsApp Alert', message, status: 'sent' })
    return { success: true }
  } catch (error) {
    await logNotification({ channel: 'whatsapp', to: phone, subject: 'WhatsApp Alert', message, status: 'failed', error: error.message })
    return { success: false, error }
  }
}

// ─── Log all notifications to Firestore ─────────────────────────
// This enables "sent even when app closed" via Firebase triggers
// and gives full audit trail of all notifications
async function logNotification({ channel, to, subject, message, status, error }) {
  try {
    await addDoc(collection(db, 'notifications'), {
      channel,
      to,
      subject,
      message,
      status,
      error: error || null,
      createdAt: serverTimestamp(),
    })
  } catch (e) {
    console.warn('Failed to log notification:', e)
  }
}

// ─── Send to all users with a given role ────────────────────────
export async function notifyByRole({ users, role, subject, message, event_type, product_name, market }) {
  const targets = users.filter(u => u.role === role && u.status === 'active')
  const results = []
  for (const user of targets) {
    if (user.email) {
      results.push(await sendEmailNotification({ to_email: user.email, to_name: user.displayName, subject, message, event_type, product_name, market }))
    }
    if (user.whatsappPhone && user.whatsappApiKey) {
      results.push(await sendWhatsAppNotification({ phone: user.whatsappPhone, apiKey: user.whatsappApiKey, message: `RAIQO Alert\n${subject}\n${message}` }))
    }
  }
  return results
}

// ─── Event-based notification rules ────────────────────────────
export const NOTIFICATION_RULES = {
  RA_UPDATE_SUBMITTED: {
    label: 'New regulatory update submitted',
    notifyRoles: ['qa_manager', 'qa_officer', 'ra_manager'],
    priority: 'high',
  },
  BATCH_BLOCKED: {
    label: 'Batch release blocked',
    notifyRoles: ['qa_manager', 'ra_manager', 'app_admin'],
    priority: 'critical',
  },
  RENEWAL_DUE_90: {
    label: 'Registration renewal due in 90 days',
    notifyRoles: ['ra_manager', 'ra_officer'],
    priority: 'high',
  },
  RENEWAL_DUE_30: {
    label: 'Registration renewal due in 30 days',
    notifyRoles: ['ra_manager', 'app_admin'],
    priority: 'critical',
  },
  VARIATION_APPROVED: {
    label: 'Variation approved — implementation required',
    notifyRoles: ['qa_manager', 'qa_officer', 'ra_manager'],
    priority: 'high',
  },
  VENDOR_MISMATCH: {
    label: 'SAP vendor mismatch detected',
    notifyRoles: ['qa_manager', 'procurement_officer'],
    priority: 'critical',
  },
  QA_ASSESSMENT_REQUIRED: {
    label: 'QA assessment required',
    notifyRoles: ['qa_officer', 'qa_manager'],
    priority: 'high',
  },
  QMS_ACTION_OVERDUE: {
    label: 'QMS action overdue',
    notifyRoles: ['qa_manager', 'app_admin'],
    priority: 'critical',
  },
}
