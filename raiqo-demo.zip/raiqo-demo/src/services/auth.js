// src/services/auth.js
import { signInWithEmailAndPassword, signOut, updatePassword, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth'
import { doc, getDoc, updateDoc, serverTimestamp } from 'firebase/firestore'
import { auth, db } from './firebase'

// Sign in with user ID (mapped to email internally)
// Admin creates users with an ID; email is stored as id@raiqo-demo.app
export async function signIn(userId, password) {
  const email = normalizeEmail(userId)
  const cred = await signInWithEmailAndPassword(auth, email, password)
  const profile = await getUserProfile(cred.user.uid)
  if (profile?.status === 'inactive') {
    await signOut(auth)
    throw new Error('Your account has been deactivated. Contact your administrator.')
  }
  await updateDoc(doc(db, 'users', cred.user.uid), { lastLogin: serverTimestamp() })
  return { user: cred.user, profile }
}

export async function logOut() {
  await signOut(auth)
}

export async function getUserProfile(uid) {
  const snap = await getDoc(doc(db, 'users', uid))
  return snap.exists() ? { id: snap.id, ...snap.data() } : null
}

export async function changePassword(currentPassword, newPassword) {
  const user = auth.currentUser
  if (!user) throw new Error('Not authenticated')
  const credential = EmailAuthProvider.credential(user.email, currentPassword)
  await reauthenticateWithCredential(user, credential)
  await updatePassword(user, newPassword)
  await updateDoc(doc(db, 'users', user.uid), { passwordChanged: true, updatedAt: serverTimestamp() })
}

export function normalizeEmail(userId) {
  if (userId.includes('@')) return userId.toLowerCase()
  return `${userId.toLowerCase()}@raiqo-demo.app`
}

// Role display names
export const ROLES = {
  app_admin: 'App Admin',
  ra_manager: 'RA Manager',
  ra_officer: 'RA Officer',
  qa_manager: 'QA Manager',
  qa_officer: 'QA Officer',
  supply_chain: 'Supply Chain Manager',
  procurement_officer: 'Procurement Officer',
  manufacturing_manager: 'Manufacturing Manager',
  medical_affairs: 'Medical Affairs',
  regulatory_director: 'Regulatory Director',
  executive: 'Executive / Viewer',
}

// Role permissions
export const PERMISSIONS = {
  app_admin: ['all'],
  regulatory_director: ['view_all', 'approve_ra', 'approve_submissions', 'manage_registrations', 'view_reports'],
  ra_manager: ['view_all', 'create_updates', 'approve_updates', 'manage_registrations', 'manage_variations', 'manage_renewals', 'view_reports'],
  ra_officer: ['view_all', 'create_updates', 'manage_registrations', 'view_variations', 'view_renewals'],
  qa_manager: ['view_all', 'create_qa_assessment', 'approve_batch_release', 'override_batch', 'manage_qms', 'view_reports'],
  qa_officer: ['view_all', 'create_qa_assessment', 'run_batch_check', 'view_qms'],
  supply_chain: ['view_registrations', 'view_batch', 'view_dashboard'],
  procurement_officer: ['view_vendors', 'view_updates', 'view_dashboard'],
  manufacturing_manager: ['view_updates', 'view_batch', 'view_dashboard'],
  medical_affairs: ['view_registrations', 'view_updates', 'view_dashboard'],
  executive: ['view_dashboard', 'view_reports'],
}

export function hasPermission(userRole, permission) {
  if (!userRole) return false
  const perms = PERMISSIONS[userRole] || []
  return perms.includes('all') || perms.includes(permission)
}
